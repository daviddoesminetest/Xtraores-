xtraores  = {}
xtraores.path = minetest.get_modpath("xtraores")

dofile(xtraores.path .. "/ores.lua")
dofile(xtraores.path .. "/items.lua")
dofile(xtraores.path .. "/tools.lua")
dofile(xtraores.path .. "/armor.lua")
dofile(xtraores.path .. "/oreblocks.lua")
dofile(xtraores.path .. "/special_weapons.lua")
dofile(xtraores.path .. "/other_blocks.lua")
